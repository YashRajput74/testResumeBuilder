

import { useResume } from "../../context/ResumeContext";

export default function Skills() {
  const { data, style, editMode, updateField } = useResume();

  const handleBlur = (index, e) => {
    const newValue = e.target.textContent.trim();
    const updatedSkills = [...data.skills];
    updatedSkills[index] = newValue;
    updateField("skills", null, updatedSkills); 
  };

  if (style.skills?.list) {
    return (
      <div className="skills" style={style?.skills?.box}>
        <h2 style={style?.skills?.heading}>Skills</h2>
        <ul style={style?.skills?.wholeList}>
          {data.skills.map((skill, index) => (
            <li
              key={index}
              contentEditable={editMode}
              suppressContentEditableWarning={true}
              onBlur={(e) => handleBlur(index, e)}
              style={style?.skills?.listItem}
            >
              {skill}
            </li>
          ))}
        </ul>
      </div>
    );
  } else {
    return (
      <div className="skills" style={style?.skills?.box}>
        <h2 style={style?.skills?.heading}>Skills</h2>
        <div className="individualSkill" style={style?.skills?.everySkillBox}>
          {data.skills.map((skill, index) => (
            <div
              key={index}
              contentEditable={editMode}
              suppressContentEditableWarning={true}
              onBlur={(e) => handleBlur(index, e)}
              style={style?.skills?.eachSkillBox}
            >
              {skill}
            </div>
          ))}
        </div>
      </div>
    );
  }
}



